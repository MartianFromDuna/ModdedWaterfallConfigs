Modded Waterfall Configs is a set of patches to modded parts that either didn't have waterfall configs before, or didn't have features that new configs have, and adds them to the game. 

This mod is nowhere near fully done, so suggestions and/or bug reports are welcome!

It's also why you can't find this on the forum or any other place right now, this is very feature-incomplete.

Anywho, that's about it. Not even sure why I put a readme here. Maybe I'll name it to something else so you don't feel obliged to read this. 

Also, how are you supposed to end one of these documents? 